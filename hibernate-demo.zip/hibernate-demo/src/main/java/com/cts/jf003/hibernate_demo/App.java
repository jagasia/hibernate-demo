package com.cts.jf003.hibernate_demo;

import java.util.List;

import model.Engineer;
import model.EngineerDao;
import model.EngineerDaoImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        EngineerDao edao=new EngineerDaoImpl();
        List<Engineer> result = edao.read();
        for(Engineer e:result)
        	System.out.println(e);
    }
}
