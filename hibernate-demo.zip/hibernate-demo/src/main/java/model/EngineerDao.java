package model;

import java.io.Serializable;
import java.util.List;

public interface EngineerDao {

	//all these methods need session
	Serializable create(Engineer engineer);

	List<Engineer> read();

	Engineer read(Long engineerId);

	void update(Engineer engineer);

	void delete(Long engineerId);

}