package model;

import java.io.Serializable;
import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class EngineerDaoImpl implements EngineerDao {

	private Session getSession()
	{
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory sf = config.buildSessionFactory();
		Session session = sf.openSession();		//here we login to the db server
		return session;
	}
	
	//all these methods need session
	public Serializable create(Engineer engineer)
	{
		Session session = getSession();
		Transaction tran = session.beginTransaction();
		Serializable id = session.save(engineer);
		tran.commit();
		session.close();
		return id;
	}
	
	public List<Engineer> read()
	{
		Session session = getSession();
		Criteria criteria = session.createCriteria(Engineer.class);
		List<Engineer> engineers = criteria.list();
		session.close();
		return engineers;
	}

	public Engineer read(Long engineerId)
	{
		Session session = getSession();
		Engineer e1= (Engineer) session.get(Engineer.class, engineerId);
		session.close();
		return e1;
	}

	public void update(Engineer engineer)
	{
		Session session = getSession();		
		Engineer e1 = (Engineer) session.get(Engineer.class, engineer.getEngineerId());
		e1.setFirstName(engineer.getFirstName());
		e1.setLastName(engineer.getLastName());
		e1.setAddress(engineer.getAddress());
		Transaction tran = session.beginTransaction();
		session.persist(e1);
		tran.commit();
		session.close();
	}

	public void delete(Long engineerId)
	{
		Session session = getSession();
		Engineer e1=(Engineer) session.get(Engineer.class, engineerId);
		 Transaction tran = session.beginTransaction();
		session.delete(e1);
		tran.commit();
		session.close();
	}
}
